README

"ImageViewer" is an ultra-minimalistic image viewing program for Windows built with C and SDL2 by Introscopia in 2020.

Enjoy.