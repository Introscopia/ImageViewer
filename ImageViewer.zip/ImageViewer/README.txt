README

"ImageViewer" is an ultra-minimalistic image viewing program for Windows built with C and SDL2 by Introscopia in 2020.

> click and drag to pan.
> mouse wheel to zoom.
> [spacebar] to fit image to window.
> [1] to set zoom 1:1.
> [c] to cycle through background colors.
> [LEFT/RIGHT ARROWS] to navigate to other images in the same folder.

Enjoy!